module Pong {
	exports application;

	requires javafx.base;
	requires javafx.graphics;
}